
1. Pre-Requisites

   Before proceeding with the installation, it's always a good idea to make sure your sources and existing software are updated. 

	sudo apt-get update 
	sudo apt-get upgrade

2. Installing PHP 7.1

   Next step is to install PHP along with several extra packages that would prove useful if you are going to work with Laravel.

	sudo add-apt-repository ppa:ondrej/php
	sudo apt-get update
	sudo apt-get install php7.1 php7.1-mcrypt php7.1-xml php7.1-gd php7.1-opcache php7.1-mbstring

3. Installing Apache

   It's time to install Apache server now. We would also need to install libapache2-mod-php7.1 package to hook up Apache with PHP.

	sudo apt-get install apache2 libapache2-mod-php7.1

4. Installing Mysql

   Now that we have our web server up and running, it is time to install MySQL. MySQL is a database management system. Basically, it will organize and provide access to databases where our site can store information.

	sudo apt-get install mysql-server php7.1-mysql

5. Installing Composer

   	sudo apt-get install curl php7.1-cli git

	curl -sS https://getcomposer.org/installer | sudo php -- --install-dir=/usr/local/bin --filename=composer

6. Installing project
   
  - Download source code via Github

	cd /var/www/html/
	sudo git clone https://github.com/sarapis/PBNYC.git
	sudo chmod -R 777 PBNYC

  - Create a MySQL database for the project

	mysql -u root -p,
	create database mypb;
	\q

  -From the projects root run

	cp .example.env .env

  -Configure your .env file	     

  -Run [ composer update ] from the projects root folder

  -Database Migration

	sudo php artisan key:generate 
	sudo php artisan migrate
	sudo php artisan db:seed	

7. Configuring Apache

   Now that we have installed project, we move on to the step of configuring Apache web server.

   Now go to the /etc/apache2/sites-available directory and use the following command to create a configuration file for our project install.

   	cd /etc/apache2/sites-available
	sudo nano laravel.conf

   Now add the following content to the file and close it after saving. Replace yourdomain.tld with the domain name of your website inside the file.

	<VirtualHost *:80>
    	    ServerName yourdomain.tld

    	    ServerAdmin webmaster@localhost
    	    DocumentRoot /var/www/html/PBNYC/public
	
            <Directory /var/www/html/PBNYC>
        	AllowOverride All
            </Directory>

            ErrorLog ${APACHE_LOG_DIR}/error.log
            CustomLog ${APACHE_LOG_DIR}/access.log combined
        </VirtualHost>
	
   Now we have to enable this newly created .conf file and disable the default .conf file that is installed with the default Apache install. Also, we need to enable mod_rewrite so that permalinks can function properly.

	sudo a2dissite 000-default.conf
	sudo a2ensite laravel.conf
	sudo a2enmod rewrite
	sudo service apache2 restart


Visit the IP address or domain name of your server with a web browser. You will see the project Home page.

-------------------------  End -----------------------------------------------------------------------