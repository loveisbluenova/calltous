import { NgModule, ErrorHandler } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { IonicApp, IonicModule, IonicErrorHandler } from 'ionic-angular';
import { MyApp } from './app.component';
import { CapturePage } from '../pages/capture/capture';
import { ComparePage } from '../pages/compare/compare';
import { Compare2Page } from '../pages/compare2/compare2';
import { DescribePage } from '../pages/describe/describe';
import { OpinionsPage } from '../pages/opinions/opinions';
import { ProfilePage } from '../pages/profile/profile';
import { TabsControllerPage } from '../pages/tabs-controller/tabs-controller';
import { HomePage } from '../pages/home/home';
import { LearnAboutAdsPage } from '../pages/learn-about-ads/learn-about-ads';
import { SearchAdsPage } from '../pages/search-ads/search-ads';
import { MyProfilePage } from '../pages/my-profile/my-profile';
import { LoginPage } from '../pages/login/login';
import { SignupPage } from '../pages/signup/signup';
import { BrowseAdsPage } from '../pages/browse-ads/browse-ads';


import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';

@NgModule({
  declarations: [
    MyApp,
    CapturePage,
    ComparePage,
    Compare2Page,
    DescribePage,
    OpinionsPage,
    ProfilePage,
    TabsControllerPage,
    HomePage,
    LearnAboutAdsPage,
    SearchAdsPage,
    MyProfilePage,
    LoginPage,
    SignupPage,
    BrowseAdsPage
  ],
  imports: [
    BrowserModule,
    IonicModule.forRoot(MyApp)
  ],
  bootstrap: [IonicApp],
  entryComponents: [
    MyApp,
    CapturePage,
    ComparePage,
    Compare2Page,
    DescribePage,
    OpinionsPage,
    ProfilePage,
    TabsControllerPage,
    HomePage,
    LearnAboutAdsPage,
    SearchAdsPage,
    MyProfilePage,
    LoginPage,
    SignupPage,
    BrowseAdsPage
  ],
  providers: [
    StatusBar,
    SplashScreen,
    {provide: ErrorHandler, useClass: IonicErrorHandler}
  ]
})
export class AppModule {}