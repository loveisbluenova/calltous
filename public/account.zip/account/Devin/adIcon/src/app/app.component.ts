import { Component, ViewChild } from '@angular/core';
import { Platform, Nav } from 'ionic-angular';
import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';

import { CapturePage } from '../pages/capture/capture';
import { DescribePage } from '../pages/describe/describe';
import { ComparePage } from '../pages/compare/compare';
import { Compare2Page } from '../pages/compare2/compare2';
import { OpinionsPage } from '../pages/opinions/opinions';
import { ProfilePage } from '../pages/profile/profile';
import { LearnAboutAdsPage } from '../pages/learn-about-ads/learn-about-ads';
import { SearchAdsPage } from '../pages/search-ads/search-ads';
import { MyProfilePage } from '../pages/my-profile/my-profile';


import { HomePage } from '../pages/home/home';



@Component({
  templateUrl: 'app.html'
})
export class MyApp {
  @ViewChild(Nav) navCtrl: Nav;
    rootPage:any = HomePage;

  constructor(platform: Platform, statusBar: StatusBar, splashScreen: SplashScreen) {
    platform.ready().then(() => {
      // Okay, so the platform is ready and our plugins are available.
      // Here you can do any higher level native things you might need.
      statusBar.styleDefault();
      splashScreen.hide();
    });
  }
  goToCapture(params){
    if (!params) params = {};
    this.navCtrl.setRoot(CapturePage);
  }goToDescribe(params){
    if (!params) params = {};
    this.navCtrl.setRoot(DescribePage);
  }goToCompare(params){
    if (!params) params = {};
    this.navCtrl.setRoot(ComparePage);
  }goToCompare2(params){
    if (!params) params = {};
    this.navCtrl.setRoot(Compare2Page);
  }goToOpinions(params){
    if (!params) params = {};
    this.navCtrl.setRoot(OpinionsPage);
  }goToProfile(params){
    if (!params) params = {};
    this.navCtrl.setRoot(ProfilePage);
  }goToHome(params){
    if (!params) params = {};
    this.navCtrl.setRoot(HomePage);
  }goToLearnAboutAds(params){
    if (!params) params = {};
    this.navCtrl.setRoot(LearnAboutAdsPage);
  }goToSearchAds(params){
    if (!params) params = {};
    this.navCtrl.setRoot(SearchAdsPage);
  }goToMyProfile(params){
    if (!params) params = {};
    this.navCtrl.setRoot(MyProfilePage);
  }
}
