import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { Compare2Page } from '../compare2/compare2';
import { OpinionsPage } from '../opinions/opinions';
import { ProfilePage } from '../profile/profile';
import { CapturePage } from '../capture/capture';
import { DescribePage } from '../describe/describe';
import { ComparePage } from '../compare/compare';

@Component({
  selector: 'page-compare',
  templateUrl: 'compare.html'
})
export class ComparePage {

  constructor(public navCtrl: NavController) {
  }
  goToCompare2(params){
    if (!params) params = {};
    this.navCtrl.push(Compare2Page);
  }goToOpinions(params){
    if (!params) params = {};
    this.navCtrl.push(OpinionsPage);
  }goToProfile(params){
    if (!params) params = {};
    this.navCtrl.push(ProfilePage);
  }goToCapture(params){
    if (!params) params = {};
    this.navCtrl.push(CapturePage);
  }goToDescribe(params){
    if (!params) params = {};
    this.navCtrl.push(DescribePage);
  }goToCompare(params){
    if (!params) params = {};
    this.navCtrl.push(ComparePage);
  }
}
