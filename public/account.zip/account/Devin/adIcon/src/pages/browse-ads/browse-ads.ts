import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-browse-ads',
  templateUrl: 'browse-ads.html'
})
export class BrowseAdsPage {

  constructor(public navCtrl: NavController) {
  }
  
}
