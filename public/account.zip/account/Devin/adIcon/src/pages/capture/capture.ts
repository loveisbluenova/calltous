import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { DescribePage } from '../describe/describe';
import { ComparePage } from '../compare/compare';
import { Compare2Page } from '../compare2/compare2';
import { OpinionsPage } from '../opinions/opinions';
import { ProfilePage } from '../profile/profile';
import { CapturePage } from '../capture/capture';

@Component({
  selector: 'page-capture',
  templateUrl: 'capture.html'
})
export class CapturePage {

  constructor(public navCtrl: NavController) {
  }
  goToDescribe(params){
    if (!params) params = {};
    this.navCtrl.push(DescribePage);
  }goToCompare(params){
    if (!params) params = {};
    this.navCtrl.push(ComparePage);
  }goToCompare2(params){
    if (!params) params = {};
    this.navCtrl.push(Compare2Page);
  }goToOpinions(params){
    if (!params) params = {};
    this.navCtrl.push(OpinionsPage);
  }goToProfile(params){
    if (!params) params = {};
    this.navCtrl.push(ProfilePage);
  }goToCapture(params){
    if (!params) params = {};
    this.navCtrl.push(CapturePage);
  }
}
