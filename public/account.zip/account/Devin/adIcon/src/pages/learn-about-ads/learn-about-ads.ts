import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-learn-about-ads',
  templateUrl: 'learn-about-ads.html'
})
export class LearnAboutAdsPage {

  constructor(public navCtrl: NavController) {
  }
  
}
