import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-search-ads',
  templateUrl: 'search-ads.html'
})
export class SearchAdsPage {

  constructor(public navCtrl: NavController) {
  }
  
}
