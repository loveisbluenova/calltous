import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { DescribePage } from '../describe/describe';
import { ComparePage } from '../compare/compare';
import { Compare2Page } from '../compare2/compare2';
import { OpinionsPage } from '../opinions/opinions';
import { ProfilePage } from '../profile/profile';
import { CapturePage } from '../capture/capture';
import { CapturePage } from '../capture/capture';
import { DescribePage } from '../describe/describe';
import { ComparePage } from '../compare/compare';
import { OpinionsPage } from '../opinions/opinions';
import { ProfilePage } from '../profile/profile';

@Component({
  selector: 'page-tabs-controller',
  templateUrl: 'tabs-controller.html'
})
export class TabsControllerPage {

  tab1Root: any = CapturePage;
  tab2Root: any = DescribePage;
  tab3Root: any = ComparePage;
  tab4Root: any = OpinionsPage;
  tab5Root: any = ProfilePage;
  constructor(public navCtrl: NavController) {
  }
  goToDescribe(params){
    if (!params) params = {};
    this.navCtrl.push(DescribePage);
  }goToCompare(params){
    if (!params) params = {};
    this.navCtrl.push(ComparePage);
  }goToCompare2(params){
    if (!params) params = {};
    this.navCtrl.push(Compare2Page);
  }goToOpinions(params){
    if (!params) params = {};
    this.navCtrl.push(OpinionsPage);
  }goToProfile(params){
    if (!params) params = {};
    this.navCtrl.push(ProfilePage);
  }goToCapture(params){
    if (!params) params = {};
    this.navCtrl.push(CapturePage);
  }
}
