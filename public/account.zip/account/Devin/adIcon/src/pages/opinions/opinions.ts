import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { ProfilePage } from '../profile/profile';
import { OpinionsPage } from '../opinions/opinions';
import { CapturePage } from '../capture/capture';
import { DescribePage } from '../describe/describe';
import { ComparePage } from '../compare/compare';
import { Compare2Page } from '../compare2/compare2';

@Component({
  selector: 'page-opinions',
  templateUrl: 'opinions.html'
})
export class OpinionsPage {

  constructor(public navCtrl: NavController) {
  }
  goToProfile(params){
    if (!params) params = {};
    this.navCtrl.push(ProfilePage);
  }goToOpinions(params){
    if (!params) params = {};
    this.navCtrl.push(OpinionsPage);
  }goToCapture(params){
    if (!params) params = {};
    this.navCtrl.push(CapturePage);
  }goToDescribe(params){
    if (!params) params = {};
    this.navCtrl.push(DescribePage);
  }goToCompare(params){
    if (!params) params = {};
    this.navCtrl.push(ComparePage);
  }goToCompare2(params){
    if (!params) params = {};
    this.navCtrl.push(Compare2Page);
  }
}
